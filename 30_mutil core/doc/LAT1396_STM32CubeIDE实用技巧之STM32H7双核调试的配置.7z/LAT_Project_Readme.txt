该例程源自STM32H7的Cube固件包中，GPIO外部中断的例程：
STM32Cube_FW_H7_V1.11.0\Projects\NUCLEO-H745ZI-Q\Examples\GPIO\GPIO_EXTI

请将该文件夹解压到如下目录，即可正确编译：STM32Cube_FW_H7_V1.11.0\Projects\NUCLEO-H745ZI-Q\Examples\GPIO